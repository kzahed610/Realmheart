#!/usr/bin/env python3
"""Author Tessia's directional hair flow maps and review artifacts.

This is an offline asset-generation tool, not a Realmheart runtime dependency.
It estimates strand tangents from the painted hair texture, blends uncertain
regions toward the overall downward drape, and neutralizes roots plus the
body-facing seam. Output RG channels decode as ``direction * 0.5 + 0.5``;
blue remains neutral and alpha exactly follows the hair texture.

Dependencies: numpy, Pillow, scipy. OpenCV is optional and only required for
``--preview-video``.
"""

from __future__ import annotations

import argparse
import math
from pathlib import Path
from typing import NamedTuple

import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import gaussian_filter, sobel


class FlowResult(NamedTuple):
    hair_rgba: np.ndarray
    movement: np.ndarray
    encoded_rgba: np.ndarray
    vector_x: np.ndarray
    vector_y: np.ndarray
    coherence: np.ndarray


def _weighted_blur(values: np.ndarray, weight: np.ndarray, sigma: float) -> np.ndarray:
    numerator = gaussian_filter(values * weight, sigma=sigma, mode="nearest")
    denominator = gaussian_filter(weight, sigma=sigma, mode="nearest")
    return numerator / np.maximum(denominator, 1.0e-6)


def _visible_right_edge(alpha: np.ndarray) -> np.ndarray:
    height, width = alpha.shape
    result = np.full(height, width - 1, dtype=np.int32)
    for row in range(height):
        visible = np.flatnonzero(alpha[row] > 0.02)
        if visible.size:
            result[row] = int(visible[-1])
    return result


def generate_flow_map(hair_path: Path, mask_path: Path) -> FlowResult:
    hair = np.asarray(Image.open(hair_path).convert("RGBA"), dtype=np.float32) / 255.0
    mask_rgba = np.asarray(Image.open(mask_path).convert("RGBA"), dtype=np.float32) / 255.0

    alpha = hair[..., 3]
    visible = alpha > 0.02
    movement = mask_rgba[..., :3].mean(axis=2) * mask_rgba[..., 3]

    luminance = (
        (0.2126 * hair[..., 0])
        + (0.7152 * hair[..., 1])
        + (0.0722 * hair[..., 2])
    )
    # Fill transparent pixels before taking gradients so the alpha silhouette
    # does not dominate the orientation estimate.
    filled_luminance = _weighted_blur(luminance, alpha, sigma=5.0)
    working_luminance = np.where(visible, luminance, filled_luminance)
    working_luminance = gaussian_filter(working_luminance, sigma=1.2, mode="nearest")

    gradient_x = sobel(working_luminance, axis=1, mode="nearest") / 8.0
    gradient_y = sobel(working_luminance, axis=0, mode="nearest") / 8.0
    structure_weight = gaussian_filter(alpha, sigma=1.0)
    tensor_xx = _weighted_blur(gradient_x * gradient_x, structure_weight, sigma=5.5)
    tensor_xy = _weighted_blur(gradient_x * gradient_y, structure_weight, sigma=5.5)
    tensor_yy = _weighted_blur(gradient_y * gradient_y, structure_weight, sigma=5.5)

    # The dominant structure-tensor eigenvector follows the image gradient.
    # Hair strand direction is perpendicular to it.
    gradient_angle = 0.5 * np.arctan2(
        2.0 * tensor_xy,
        tensor_xx - tensor_yy,
    )
    tangent_x = -np.sin(gradient_angle)
    tangent_y = np.cos(gradient_angle)
    upward = tangent_y < 0.0
    tangent_x = np.where(upward, -tangent_x, tangent_x)
    tangent_y = np.where(upward, -tangent_y, tangent_y)

    coherence = np.sqrt(
        ((tensor_xx - tensor_yy) ** 2) + (4.0 * tensor_xy * tensor_xy)
    ) / np.maximum(tensor_xx + tensor_yy, 1.0e-7)
    coherence = np.clip(coherence, 0.0, 1.0)

    height, width = alpha.shape
    yy, xx = np.mgrid[0:height, 0:width]
    row_weight = alpha.sum(axis=1)
    row_center = np.divide(
        (alpha * xx).sum(axis=1),
        np.maximum(row_weight, 1.0e-6),
    )[:, None]

    # Low-detail regions follow a conservative downward drape rather than a
    # noisy local orientation. A small outward component preserves the broad
    # curvature of the authored silhouette.
    relative_x = (xx - row_center) / max(width * 0.5, 1.0)
    fallback_x = np.clip(relative_x * 0.30, -0.32, 0.32)
    fallback_y = np.ones_like(fallback_x)
    fallback_length = np.sqrt((fallback_x * fallback_x) + (fallback_y * fallback_y))
    fallback_x /= fallback_length
    fallback_y /= fallback_length

    local_weight = np.clip((coherence - 0.10) / 0.65, 0.0, 1.0)
    local_weight *= np.clip(alpha * 1.4, 0.0, 1.0)
    vector_x = (local_weight * tangent_x) + ((1.0 - local_weight) * fallback_x)
    vector_y = (local_weight * tangent_y) + ((1.0 - local_weight) * fallback_y)

    vector_x = _weighted_blur(vector_x, alpha, sigma=3.2)
    vector_y = _weighted_blur(vector_y, alpha, sigma=3.2)
    vector_length = np.sqrt((vector_x * vector_x) + (vector_y * vector_y))
    vector_x /= np.maximum(vector_length, 1.0e-6)
    vector_y /= np.maximum(vector_length, 1.0e-6)

    # The grayscale movement mask will be applied again by the runtime shader.
    # Here it is used only as a binary/soft safety gate around authored roots.
    movable_gate = np.clip((movement - 0.035) / 0.16, 0.0, 1.0)

    # Pin the actual visible right seam, not the padded PNG canvas edge. This
    # prevents flow sampling from reopening the same body/hair crack previously
    # fixed in the macro mesh renderer.
    right_edges = _visible_right_edge(alpha)
    distance_from_seam = right_edges[:, None] - xx
    seam_gate = np.clip(distance_from_seam / 14.0, 0.0, 1.0)
    seam_gate = gaussian_filter(seam_gate, sigma=1.5)

    normalized_y = yy / max(height - 1, 1)
    root_gate = np.clip((normalized_y - 0.035) / 0.16, 0.0, 1.0)
    magnitude = np.clip(movable_gate * seam_gate * root_gate, 0.0, 1.0)
    magnitude *= np.clip(0.45 + (0.55 * coherence), 0.0, 1.0)
    magnitude = gaussian_filter(magnitude * alpha, sigma=1.0)

    vector_x *= magnitude
    vector_y *= magnitude

    encoded = np.zeros((height, width, 4), dtype=np.uint8)
    encoded[..., 0] = np.clip(np.rint(128.0 + (127.0 * vector_x)), 0, 255).astype(np.uint8)
    encoded[..., 1] = np.clip(np.rint(128.0 + (127.0 * vector_y)), 0, 255).astype(np.uint8)
    encoded[..., 2] = 128
    encoded[..., 3] = np.clip(np.rint(alpha * 255.0), 0, 255).astype(np.uint8)
    encoded[~visible, :3] = 128

    return FlowResult(hair, movement, encoded, vector_x, vector_y, coherence)


def _checkerboard(height: int, width: int, cell: int = 16) -> np.ndarray:
    yy, xx = np.mgrid[0:height, 0:width]
    parity = (xx // cell + yy // cell) % 2
    dark = np.array([42, 42, 46], dtype=np.uint8)
    light = np.array([62, 62, 68], dtype=np.uint8)
    return np.where(parity[..., None] == 0, dark, light)


def _composite(rgba: np.ndarray, background: np.ndarray) -> np.ndarray:
    alpha = rgba[..., 3:4].astype(np.float32) / 255.0
    return np.clip(
        (rgba[..., :3].astype(np.float32) * alpha)
        + (background.astype(np.float32) * (1.0 - alpha)),
        0,
        255,
    ).astype(np.uint8)


def _direction_visualization(flow: FlowResult) -> np.ndarray:
    vector_x = flow.vector_x
    vector_y = flow.vector_y
    magnitude = np.sqrt((vector_x * vector_x) + (vector_y * vector_y))
    angle = (np.arctan2(vector_y, vector_x) + math.pi) / (2.0 * math.pi)

    # Manual HSV-to-RGB conversion keeps the authoring tool independent from
    # OpenCV for normal map/review generation.
    hue = angle * 6.0
    sector = np.floor(hue).astype(np.int32) % 6
    fraction = hue - np.floor(hue)
    saturation = np.clip(magnitude * 1.4, 0.0, 1.0)
    value = 0.35 + (0.65 * np.clip(magnitude, 0.0, 1.0))
    p = value * (1.0 - saturation)
    q = value * (1.0 - (saturation * fraction))
    t = value * (1.0 - (saturation * (1.0 - fraction)))

    rgb = np.empty((*magnitude.shape, 3), dtype=np.float32)
    choices = (
        (value, t, p),
        (q, value, p),
        (p, value, t),
        (p, q, value),
        (t, p, value),
        (value, p, q),
    )
    for index, channels in enumerate(choices):
        selected = sector == index
        for channel, values in enumerate(channels):
            rgb[..., channel][selected] = values[selected]

    alpha = flow.encoded_rgba[..., 3:4]
    return np.concatenate(
        [np.clip(np.rint(rgb * 255.0), 0, 255).astype(np.uint8), alpha],
        axis=2,
    )


def write_review(flow: FlowResult, output_path: Path) -> None:
    height, width = flow.movement.shape
    background = _checkerboard(height, width)
    hair_rgba = np.clip(np.rint(flow.hair_rgba * 255.0), 0, 255).astype(np.uint8)
    mask_gray = np.clip(np.rint(flow.movement * 255.0), 0, 255).astype(np.uint8)
    mask_rgba = np.dstack(
        [mask_gray, mask_gray, mask_gray, hair_rgba[..., 3]]
    ).astype(np.uint8)
    direction_rgba = _direction_visualization(flow)

    arrow_panel = Image.fromarray(_composite(hair_rgba, background))
    draw = ImageDraw.Draw(arrow_panel)
    step = 32
    for y in range(step // 2, height, step):
        for x in range(step // 2, width, step):
            if flow.encoded_rgba[y, x, 3] < 32:
                continue
            dx = float(flow.vector_x[y, x]) * 15.0
            dy = float(flow.vector_y[y, x]) * 15.0
            if (dx * dx) + (dy * dy) < 3.0:
                continue
            draw.line((x, y, x + dx, y + dy), fill=(45, 230, 255), width=2)
            draw.ellipse(
                (x + dx - 2, y + dy - 2, x + dx + 2, y + dy + 2),
                fill=(255, 240, 80),
            )

    panels = (
        _composite(hair_rgba, background),
        _composite(mask_rgba, background),
        _composite(direction_rgba, background),
        np.asarray(arrow_panel),
    )
    labels = ("HAIR", "MOVEMENT MASK", "FLOW DIRECTION", "VECTOR REVIEW")
    margin = 24
    label_height = 44
    canvas = Image.new(
        "RGB",
        (width * len(panels) + margin * (len(panels) + 1), height + label_height + margin * 2),
        (18, 18, 22),
    )
    canvas_draw = ImageDraw.Draw(canvas)
    for index, panel in enumerate(panels):
        x = margin + index * (width + margin)
        canvas.paste(Image.fromarray(panel), (x, margin + label_height))
        canvas_draw.text((x, margin + 10), labels[index], fill=(235, 235, 240))

    output_path.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output_path)


def write_preview_video(flow: FlowResult, output_path: Path, seconds: float, fps: int) -> None:
    try:
        import cv2  # type: ignore
    except ImportError as exc:  # pragma: no cover - optional authoring dependency
        raise SystemExit("OpenCV is required only for --preview-video") from exc

    source = np.clip(np.rint(flow.hair_rgba * 255.0), 0, 255).astype(np.uint8)
    height, width = flow.movement.shape
    yy, xx = np.mgrid[0:height, 0:width].astype(np.float32)
    background = _checkerboard(height, width, cell=18)
    alpha_visible = source[..., 3] > 5

    seam_weight = np.ones((height, width), dtype=np.float32)
    for row in range(height):
        visible = np.flatnonzero(alpha_visible[row])
        if visible.size:
            right_edge = int(visible[-1])
            seam_weight[row] = np.clip(
                (right_edge - np.arange(width)) / max(width * 0.72, 1.0),
                0.0,
                1.0,
            )

    def remap_rgba(map_x: np.ndarray, map_y: np.ndarray) -> np.ndarray:
        result = np.empty_like(source)
        for channel in range(4):
            result[..., channel] = cv2.remap(
                source[..., channel],
                map_x,
                map_y,
                cv2.INTER_LINEAR,
                borderMode=cv2.BORDER_CONSTANT,
                borderValue=0,
            )
        return result

    output_path.parent.mkdir(parents=True, exist_ok=True)
    writer = cv2.VideoWriter(
        str(output_path),
        cv2.VideoWriter_fourcc(*"mp4v"),
        fps,
        (width * 3, height),
    )
    if not writer.isOpened():
        raise SystemExit(f"Unable to open preview video output: {output_path}")

    for frame_number in range(int(seconds * fps)):
        time = frame_number / float(fps)
        row_wave = np.sin((time * 0.78) + ((yy[:, 0] / height) * 0.55))
        mesh_dx = 10.0 * row_wave[:, None] * flow.movement * seam_weight
        mesh_map_x = xx - mesh_dx.astype(np.float32)
        mesh_map_y = yy

        phase = ((yy / height) * 5.3) + ((xx / width) * 1.2)
        pulse = (
            1.25 * np.sin((time * 1.05) + phase)
            + 0.55 * np.sin((time * 1.63) - (phase * 0.72) + 0.4)
        )
        flow_strength = flow.movement * 1.6
        flow_dx = flow.vector_x * pulse * flow_strength
        flow_dy = flow.vector_y * pulse * flow_strength

        mesh = remap_rgba(mesh_map_x, mesh_map_y)
        flow_only = remap_rgba(xx - flow_dx.astype(np.float32), yy - flow_dy.astype(np.float32))
        mesh_flow = remap_rgba(
            mesh_map_x - flow_dx.astype(np.float32),
            mesh_map_y - flow_dy.astype(np.float32),
        )

        panels = (
            _composite(mesh, background),
            _composite(flow_only, background),
            _composite(mesh_flow, background),
        )
        frame_rgb = np.concatenate(panels, axis=1)
        frame_bgr = cv2.cvtColor(frame_rgb, cv2.COLOR_RGB2BGR)
        for index, label in enumerate(("MESH ONLY", "FLOW ONLY", "MESH + FLOW")):
            cv2.putText(
                frame_bgr,
                label,
                (index * width + 14, 34),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.72,
                (255, 255, 255),
                2,
                cv2.LINE_AA,
            )
        writer.write(frame_bgr)

    writer.release()


def _validate_output(flow: FlowResult) -> None:
    alpha = flow.encoded_rgba[..., 3]
    visible = alpha > 0
    vector_magnitude = np.sqrt(
        (flow.vector_x * flow.vector_x) + (flow.vector_y * flow.vector_y)
    )
    if not np.any(visible):
        raise ValueError("Hair texture has no visible pixels")
    if np.max(vector_magnitude[visible]) < 0.25:
        raise ValueError("Generated flow map is effectively neutral")
    if not np.all(flow.encoded_rgba[~visible, :3] == 128):
        raise ValueError("Transparent padding must remain exact neutral RGB")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--character-root",
        type=Path,
        default=Path("assets/characters/tessia"),
        help="Tessia asset root relative to the Realmheart repository",
    )
    parser.add_argument(
        "--scales",
        nargs="+",
        default=("1x", "2x"),
        choices=("1x", "2x"),
    )
    parser.add_argument(
        "--review",
        type=Path,
        default=Path("assets/characters/tessia/review/rear-flow-map-review.png"),
        help="1x vector review sheet output",
    )
    parser.add_argument(
        "--preview-video",
        type=Path,
        help="Optional mesh/flow/mesh+flow MP4 preview output",
    )
    parser.add_argument("--preview-seconds", type=float, default=6.0)
    parser.add_argument("--preview-fps", type=int, default=60)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    results: dict[str, FlowResult] = {}

    for scale in args.scales:
        scale_root = args.character_root / scale
        result = generate_flow_map(
            scale_root / "hair-rear.png",
            scale_root / "hair-mask-rear.png",
        )
        _validate_output(result)
        output_path = scale_root / "hair-flow-rear.png"
        Image.fromarray(result.encoded_rgba, mode="RGBA").save(output_path)
        results[scale] = result

        visible = result.encoded_rgba[..., 3] > 0
        magnitude = np.sqrt(
            (result.vector_x * result.vector_x)
            + (result.vector_y * result.vector_y)
        )
        print(
            f"{scale}: wrote {output_path} | "
            f"mean vector={magnitude[visible].mean():.3f}, "
            f"neutral-visible={(magnitude[visible] < 0.05).mean():.1%}"
        )

    review_result = results.get("1x")
    if review_result is not None:
        write_review(review_result, args.review)
        print(f"wrote review: {args.review}")
        if args.preview_video is not None:
            write_preview_video(
                review_result,
                args.preview_video,
                seconds=args.preview_seconds,
                fps=args.preview_fps,
            )
            print(f"wrote preview: {args.preview_video}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
