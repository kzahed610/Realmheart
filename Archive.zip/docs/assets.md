# Realmheart UI assets

Realmheart keeps artwork and runtime images under `assets/`, while GTK styling
lives separately under `styles/`.

## Taskbar SVG icons

Taskbar icons live as their original SVG sources in:

```text
assets/Realmheart-Icons/
```

Realmheart does **not** convert them into GTK symbolic mirrors. The taskbar
reads each SVG source, resolves its semantic color tokens, and rasterizes it at
the requested display size. This preserves the difference between hollow
strokes, solid fills, charging bolts, and warning badges.

The supported SVG roles are documented in:

```text
assets/Realmheart-Icons/COLOR_TOKENS.md
```

- `currentColor` and `--rh-icon-primary` use the normal icon foreground.
- `--rh-icon-accent` is used for charging/warning elements.
- `--rh-icon-on-accent` is used for marks drawn inside an accent badge.

The renderer caches the resolved image until its path, size, or active theme
colors change, so normal taskbar redraws do not repeatedly parse SVG source.
