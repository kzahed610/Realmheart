# Realmheart Dependency Notes

## Required shell dependencies

- `gtk4` 4.12 or newer
- `gtk4-layer-shell`
- `glib2`
- `gdk-pixbuf-2.0`
- `cmake`
- `ninja`
- a C++20 compiler

On Arch/CachyOS:

```sh
sudo pacman -S --needed \
  base-devel cmake ninja pkgconf \
  gtk4 gtk4-layer-shell glib2 gdk-pixbuf2
```

`curl` is optional. When present, the media popup can cache remote MPRIS album
art; local `file://` artwork works without it.

## Optional native wallpaper renderer

The native backend is built when all of these are available:

- `wayland-client`
- `wayland-egl`
- EGL
- OpenGL ES 2
- `wayland-scanner`
- `wlr-protocols`

On Arch/CachyOS these are normally provided by:

```sh
sudo pacman -S --needed \
  wayland wayland-protocols wlr-protocols \
  mesa
```

CMake detects the optional stack automatically. When anything is missing, it prints a
message and still builds Realmheart with the GTK wallpaper backend.

Disable the native target explicitly with:

```sh
cmake -S . -B build -G Ninja \
  -DREALMHEART_ENABLE_NATIVE_WALLPAPER=OFF
```

If the layer-shell XML is installed in a non-standard location:

```sh
cmake -S . -B build -G Ninja \
  -DREALMHEART_WLR_LAYER_SHELL_XML=/path/to/wlr-layer-shell-unstable-v1.xml
```

Verify pkg-config discovery with:

```sh
pkg-config --atleast-version=4.12 gtk4
pkg-config --exists gtk4-layer-shell-0 gio-2.0 gdk-pixbuf-2.0
pkg-config --exists wayland-client wayland-egl egl glesv2
```

## Taskbar CSS styles

The taskbar is styled from modular GTK CSS files under `styles/taskbar/`.
They are installed under Realmheart's dedicated style directory and loaded
once when the shell starts. Editing them does
not require recompiling Realmheart; restart the shell to apply changes.

- `bar.css` — shell contour, gold border, padding, and vertical rhythm
- `icons.css` — icon button size, Matugen outline, hover/disabled states
- `workspaces.css` — workspace rune sizing and state colours
- `popovers.css` — workspace, media, battery, and system popovers

The C++ taskbar code owns behavior and live state only. Matugen palette values
remain injected by `ThemeStyles`, while the single hardcoded taskbar gold lives in `bar.css` as `rh_taskbar_gold`.
Set `REALMHEART_STYLE_DIR` to override the style root while developing or
trying an alternate skin.
