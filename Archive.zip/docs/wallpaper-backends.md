# Wallpaper backends

Realmheart keeps wallpaper state separate from wallpaper rendering. The shell talks to a
`WallpaperController`, which can use either backend without changing the picker,
persistence, theme generation, or the rest of the GTK interface.

```text
WallpaperController
├── GtkWallpaperBackend
└── NativeWallpaperBackend
    └── realmheart-wallpaper-renderer (Wayland + EGL + GLES2)
```

## Choose a backend

Start the shell with an explicit backend:

```sh
./build/realmheart --shell --wallpaper-backend gtk
./build/realmheart --shell --wallpaper-backend native
```

Or set the default for a service/session:

```sh
export REALMHEART_WALLPAPER_BACKEND=native
./build/realmheart --shell
```

Switch a running shell without restarting it:

```sh
./build/realmheart --command set-wallpaper-backend gtk
./build/realmheart --command set-wallpaper-backend native
```

The active wallpaper is reapplied before the old backend is destroyed. If the native
renderer cannot start, Realmheart automatically falls back to GTK. If the native renderer
fails while setting a wallpaper, Realmheart also retries that wallpaper through GTK.

## Native renderer behavior

The native backend is a separate process so it cannot take down the GTK shell. It creates
one layer-shell background surface for each Wayland output and shares the wallpaper texture
between those surfaces.

It currently supports:

- static wallpapers with correct `cover` cropping;
- a 350 ms crossfade during wallpaper changes;
- output hotplug and output scaling;
- decode sizing based on connected outputs rather than a hard-coded resolution;
- idle blocking when no animation is active;
- at most the current and incoming wallpaper textures during a transition.

The GTK backend remains available as the stable fallback.

## Renderer discovery

`NativeWallpaperBackend` searches for the renderer in this order:

1. `REALMHEART_WALLPAPER_RENDERER`;
2. next to the running `realmheart` executable;
3. `realmheart-wallpaper-renderer` in `PATH`.

This means a normal development build works directly from `build/`, while installed builds
work when both executables are installed into the same `bin` directory.

## Measuring the result

Compare total proportional memory, not only one process's RSS:

```sh
smem -P 'realmheart|realmheart-wallpaper-renderer' -c 'pid name rss pss uss'
```

Useful comparisons:

```text
GTK shell with GTK wallpaper
GTK shell with native wallpaper renderer
GTK shell without any wallpaper backend
```

The native backend is worth keeping when it provides a meaningful total-PSS reduction,
better animation behavior, or both.
