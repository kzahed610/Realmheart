# Luna Full Realmheart Audit — t_d4b7568b

- Task: `t_d4b7568b`
- Status: `done`
- Assignee: `luna`
- Captured: `2026-07-20T08:10:03`
- Corrected full-report capture: `2026-07-20T08:12:19`
- Workspace: `/home/zahed/Realmheart`
- Model requirement at dispatch: `luna` profile, `openai-codex` provider, `gpt-5.6-sol`, high reasoning
- Luna report source: Kanban comment by `luna` at `1784515134`

---

MAJOR

- **Location:** `src/ui/ShellApp.cpp:375-383,409-424,454-476,719-723`; `src/services/UtilityManager.cpp:120-135`; `src/ui/wallpaper/NativeWallpaperBackend.cpp:60-62,186-272`
  **Flaw:** GTK/GAction paths still execute blocking subprocess probes, native-renderer IPC, image decode, and Matugen generation synchronously on the GTK main thread.
  **Impact:** A stalled audio/brightness probe freezes the shell during OSD requests. A native wallpaper failure can consume the 5-second IPC deadline and then run fallback decode; successful wallpaper changes immediately run Matugen with a 10-second deadline. During those operations the bar, sidebar, OSD, dismissal, and shutdown event processing are unresponsive.
  **Evidence:** `ShellRuntime::set_wallpaper()` calls `WallpaperController::set_wallpaper()` and then `generate_theme_for()` inline; `UtilityManager::generate_colors()` calls `run_capture()` with a 10-second deadline.

- **Location:** `src/services/Notifications.cpp:19-29,65-80`; `src/ui/bar/VerticalBar.cpp:89-107`
  **Flaw:** Every notification copies the complete bounded history into a distinct `G_PRIORITY_DEFAULT_IDLE` payload; the bar has no queued-refresh coalescing.
  **Impact:** A notification burst can starve the lower-priority idle handlers and retain one full history copy per D-Bus call. At the configured limits, one full snapshot contains at least 6,988,800 raw payload bytes; the first 100 maximal notifications can queue 352,934,400 bytes of copied strings before allocator/container overhead. Once history is full, every additional pending notification adds another roughly 7 MB, allowing a session-bus client or runaway application to OOM the shell despite the payload/history caps.

- **Location:** `src/services/NotificationServer.cpp:18-22,36-55`; `src/services/NotificationDaemon.cpp:224-227`
  **Flaw:** `active_ids_` is unbounded. Notifications with `expire_timeout == 0` receive no expiration source and remain in the set until the sender explicitly closes them; history eviction does not retire their IDs.
  **Impact:** Persistent notifications from a misbehaving or malicious session-bus client produce permanent hash-table growth for the lifetime of Realmheart. The history cap therefore does not bound total notification state.

- **Location:** `src/ui/sidebar/RightSidebar.cpp:593-597,758-767`; `src/services/KeepAwake.cpp:58-71,83-107`
  **Flaw:** `refresh_controls()` calls `KeepAwake::active()` on the GTK thread outside `AsyncUiState::operation_mutex`, while a pooled control action can concurrently execute `KeepAwake::set_enabled()`. Both read or write the plain `child_pid_` field, and `active()` itself mutates it after `waitpid()`.
  **Impact:** Opening/refreshing the sidebar during a Keep Awake mutation creates a C++ data race and undefined behavior. Interleaving the stop path's `child_pid_ > 0` check with `active()` resetting the PID can also make the later signal target inconsistent.
  **Evidence:** The existing `KeepAwakeTests.cpp:63-72` exercises only a single-threaded enable/disable sequence and cannot detect this race.

- **Location:** `src/core/Command.cpp:408-427`
  **Flaw:** After SIGKILL, `run_capture()` performs only bounded nonblocking `waitpid(..., WNOHANG)` attempts and returns while the direct child may still be unreaped. No asynchronous reaper adopts that PID afterward.
  **Impact:** A child that does not become waitable inside the fixed 250 ms post-kill window can later become a zombie for the lifetime of Realmheart. Repeated hung commands can exhaust process-table slots.
  **Evidence:** `CommandTests.cpp:24-40` verifies timeout status and elapsed time, but does not verify eventual child reaping after `run_capture()` returns.

- **Location:** `src/ui/sidebar/RightSidebar.cpp:605-627`; `src/ui/components/SliderWidget.cpp:84-100`
  **Flaw:** The control-refresh comment claims reads are serialized with mutations, but slider mutations use each `SliderWidget::AsyncState::mutation_mutex`, not `RightSidebar::AsyncUiState::operation_mutex`. Brightness/audio refresh reads can therefore overlap slider writes, and neither result generation-orders the other path.
  **Impact:** A refresh started while the user changes brightness or volume can complete with an older value after the mutation confirmation and overwrite the slider with stale state until a later refresh.

- **Location:** `src/services/NotesService.cpp:70-77,124-157`
  **Flaw:** Note persistence reports no failure to the UI and treats userspace `flush()` plus `rename()` as durable without `fsync()` of the temporary file or containing directory.
  **Impact:** Disk-full/permission failures leave edits visibly accepted but unsaved, and a power loss can lose the latest note or rename despite the apparent atomic save. Shutdown makes one final attempt and then exits even if it fails.

- **Location:** `CMakeLists.txt:254-256`; `tests/ShellRuntimeTests.cpp:1-155`; missing `realmheart_lifetime_stress` / `shell_smoke` targets
  **Flaw:** The test named `realmheart_shell_runtime_tests` compiles only `ShellCommand.cpp` and `ShellControl.cpp`; it never constructs `ShellRuntime`, GTK windows, sidebar async controls, notification fan-out, or teardown. The task's required `build-hybrid/realmheart_lifetime_stress` and `tests/scripts/shell_smoke.sh` probes do not exist in the repository/build.
  **Impact:** The 33-test suite can pass while all main-thread blocking, GTK lifetime, notification backlog, and cross-thread races above remain unexercised.
  **Evidence:** Clean build succeeded (`ninja: no work to do`) and CTest passed 33/33 in 10.51 seconds. Invoking `build-hybrid/realmheart_lifetime_stress` failed with `No such file or directory`; repository searches found no lifetime or shell-smoke source/target.

Verification: `git diff --check` passed; working tree remained clean; no source files were modified.
