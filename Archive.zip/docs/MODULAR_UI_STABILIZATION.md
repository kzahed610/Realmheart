# Modular UI stabilization

This pass keeps the modular component design while repairing ownership, async
lifetime, theming, and clean-build regressions introduced during the initial
extraction.

## Why wallpaper colors did not update

Two independent breaks kept the fallback palette active:

1. Wallpaper changes rendered and persisted the new path, but did not invoke
   palette generation. Theme generation only happened during shell startup.
2. Matugen 4 changed its default JSON representation and introduced source-color
   selection. Realmheart's parser only understood one older representation.

Realmheart now generates a palette from the exact wallpaper path accepted by the
renderer, invokes Matugen in non-interactive dry-run mode, understands both the
legacy and newer JSON layouts, and updates one display-wide GTK CSS provider.

Expected runtime log after a successful change:

```text
[ThemeService] Palette updated. Primary=#...... background=#......
```

## UI ownership and lifecycle

- `ShellRuntime` owns `VerticalBar` and `RightSidebar` controllers.
- Surfaces hide instead of destroying their windows when toggled off.
- Each surface owns components with `std::unique_ptr<BaseWidget>`.
- Timers, signal handlers, workers, and queued main-loop results are invalidated
  before controllers are destroyed.
- `ThemeService::Subscription` automatically unsubscribes.
- One `ThemeStyles` provider supplies the palette for the display; components
  expose stable CSS classes instead of installing one provider each.

## Verification

Use a clean build so old CMake artifacts cannot hide source-list mistakes:

```bash
rm -rf build-hybrid
cmake -S . -B build-hybrid -G Ninja \
  -DREALMHEART_ENABLE_NATIVE_WALLPAPER=ON \
  -DBUILD_TESTING=ON
cmake --build build-hybrid
ctest --test-dir build-hybrid --output-on-failure
```

Test palette generation independently:

```bash
matugen image /absolute/path/to/wallpaper.png \
  --dry-run --json hex --old-json-output --source-color-index 0
```

Then test the complete Realmheart path:

```bash
./build-hybrid/realmheart --shell --wallpaper-backend native
./build-hybrid/realmheart --command set-wallpaper-path /absolute/path/to/wallpaper.png
```
