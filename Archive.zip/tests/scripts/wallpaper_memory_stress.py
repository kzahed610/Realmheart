#!/usr/bin/env python3
"""Deterministic direct-path wallpaper memory regression harness."""

from __future__ import annotations

import argparse
import csv
import json
import statistics
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from wallpaper_memory_common import collect_sample, csv_value, find_shell_pid, get_binary_info

TRACKED_METRICS = (
    "rss_kib",
    "pss_kib",
    "private_dirty_kib",
    "private_kib",
    "anonymous_kib",
    "heap_private_kib",
    "glycin_frame_count",
    "glycin_frame_private_kib",
    "dma_buf_count",
    "dma_buf_total_bytes",
    "drm_resident_system_kib",
    "fd_count",
    "thread_count",
)


def median_delta(samples: list[dict[str, Any]], metric: str, window: int = 3) -> float:
    if len(samples) < window * 2:
        raise ValueError(f"need at least {window * 2} samples")
    start = statistics.median(float(item[metric]) for item in samples[:window])
    end = statistics.median(float(item[metric]) for item in samples[-window:])
    return end - start


def linear_slope(samples: list[dict[str, Any]], metric: str) -> float:
    values = [float(item[metric]) for item in samples]
    count = len(values)
    x_mean = (count - 1) / 2.0
    y_mean = sum(values) / count
    denominator = sum((index - x_mean) ** 2 for index in range(count))
    if denominator == 0:
        return 0.0
    return sum((index - x_mean) * (value - y_mean) for index, value in enumerate(values)) / denominator


def summarize(samples: list[dict[str, Any]]) -> dict[str, Any]:
    # Compare the same image phase so expected large/small oscillation cannot masquerade as growth.
    phases = {label: [item for item in samples if item["image"] == label] for label in {item["image"] for item in samples}}
    report: dict[str, Any] = {"sample_count": len(samples), "phases": {}}
    for label, phase_samples in sorted(phases.items()):
        report["phases"][label] = {
            metric: {
                "median_delta": median_delta(phase_samples, metric),
                "slope_per_sample": linear_slope(phase_samples, metric),
            }
            for metric in TRACKED_METRICS
        }
    return report


def write_csv(path: Path, samples: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(samples[0].keys()))
        writer.writeheader()
        writer.writerows({key: csv_value(value) for key, value in row.items()} for row in samples)


def apply_wallpaper(binary: Path, fixture: Path) -> None:
    subprocess.run(
        [str(binary), "--command", "set-wallpaper-path", str(fixture)],
        check=True,
        stdout=subprocess.DEVNULL,
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--binary", type=Path, default=Path.home() / ".local/bin/realmheart")
    parser.add_argument("--iterations", type=int, default=50)
    parser.add_argument("--warmup", type=int, default=5)
    parser.add_argument("--settle", type=float, default=0.5)
    parser.add_argument("--max-growth-kib", type=float, default=1024.0)
    parser.add_argument("--allow-growth", action="store_true")
    parser.add_argument("--output-dir", type=Path, default=Path("tests/results"))
    args = parser.parse_args()

    if args.iterations < 12 or args.warmup < 0 or args.settle < 0:
        parser.error("iterations must be >= 12; warmup and settle must be non-negative")

    binary = args.binary.expanduser().resolve()
    pid = find_shell_pid(binary)
    fixtures = [
        Path("tests/fixtures/wallpapers/small.png").resolve(),
        Path("tests/fixtures/wallpapers/huge.png").resolve(),
    ]
    for fixture in fixtures:
        if not fixture.is_file():
            raise RuntimeError(f"missing fixture: {fixture}")

    binary_info = get_binary_info(binary)
    if binary_info is None:
        raise RuntimeError(f"binary does not exist: {binary}")
    print(f"binary={binary} pid={pid} sha256={binary_info['sha256']}")
    for index in range(args.warmup):
        apply_wallpaper(binary, fixtures[index % len(fixtures)])
        time.sleep(args.settle)

    samples: list[dict[str, Any]] = []
    for index in range(args.iterations):
        fixture = fixtures[index % len(fixtures)]
        apply_wallpaper(binary, fixture)
        time.sleep(args.settle)
        sample = collect_sample(pid, index, fixture.stem)
        samples.append(sample)
        if index % 10 == 0 or index == args.iterations - 1:
            print(
                f"{index + 1:02d}/{args.iterations} {fixture.stem}: "
                f"PSS={sample['pss_kib']} KiB private-dirty={sample['private_dirty_kib']} KiB "
                f"glycin={sample['glycin_frame_count']} dmabuf={sample['dma_buf_count']}"
            )

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path = args.output_dir / f"wallpaper_direct_{stamp}.csv"
    report_path = args.output_dir / f"wallpaper_direct_{stamp}.json"
    write_csv(csv_path, samples)
    report = {
        "binary": get_binary_info(binary),
        "pid": pid,
        "iterations": args.iterations,
        "warmup": args.warmup,
        "settle_seconds": args.settle,
        **summarize(samples),
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

    phase_growth = [
        phase[metric]["median_delta"]
        for phase in report["phases"].values()
        for metric in ("pss_kib", "private_dirty_kib")
    ]
    worst_growth = max(phase_growth)
    print(f"worst same-phase PSS/private-dirty growth={worst_growth:.1f} KiB")
    print(f"csv={csv_path} report={report_path}")
    if worst_growth > args.max_growth_kib and not args.allow_growth:
        print("RESULT=RED")
        return 1
    print("RESULT=GREEN" if worst_growth <= args.max_growth_kib else "RESULT=RED_ALLOWED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
