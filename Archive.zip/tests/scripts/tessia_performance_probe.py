#!/usr/bin/env python3
"""Measure Tessia's incremental memory and CPU cost in the live Realmheart shell.

The probe measures the sidebar both with and without Tessia so character cost
is separated from the sidebar's own open-state work. It also repeats a warmed
load/render/release cycle to distinguish one-time GTK renderer initialization
from resources retained by Tessia itself. It restores the user's original
character preference and uses only the Python standard library and Linux /proc.
"""

from __future__ import annotations

import argparse
import csv
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import datetime
from typing import Callable, Iterable

SERVICE = "realmheart.service"
DEFAULT_INTERVAL = 0.25


@dataclass(frozen=True)
class Sample:
    phase: str
    elapsed_s: float
    cpu_one_core_pct: float
    rss_kib: int
    pss_kib: int
    private_kib: int
    anonymous_kib: int
    swap_kib: int
    threads: int
    fds: int


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Profile Realmheart Tessia memory, CPU, and release behavior."
    )
    parser.add_argument(
        "--binary",
        type=Path,
        default=Path("build-hybrid/realmheart"),
        help="Realmheart command binary (default: build-hybrid/realmheart)",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("/tmp"),
        help="Directory for CSV and summary output (default: /tmp)",
    )
    parser.add_argument(
        "--interval",
        type=float,
        default=DEFAULT_INTERVAL,
        help="Sampling interval in seconds (default: 0.25)",
    )
    parser.add_argument(
        "--quick",
        action="store_true",
        help="Use shorter phases and fewer animation cycles",
    )
    return parser.parse_args()


def run(*args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        args,
        check=check,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def preference_path() -> Path:
    config_home = os.environ.get("XDG_CONFIG_HOME")
    if config_home:
        return Path(config_home) / "realmheart/features/sidebar-character.enabled"
    return Path.home() / ".config/realmheart/features/sidebar-character.enabled"


def preference_enabled(data: bytes | None) -> bool:
    if data is None:
        return True
    value = data.decode("utf-8", errors="replace").strip().lower()
    if value in {"0", "false", "off", "disabled", "no"}:
        return False
    return True


def write_preference(path: Path, enabled: bool) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".probe.tmp")
    temporary.write_text("enabled\n" if enabled else "disabled\n", encoding="utf-8")
    temporary.replace(path)


def restore_preference(path: Path, original: bytes | None) -> None:
    if original is None:
        path.unlink(missing_ok=True)
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".probe.restore.tmp")
    temporary.write_bytes(original)
    temporary.replace(path)


def restart_service() -> int:
    run("systemctl", "--user", "restart", SERVICE)
    deadline = time.monotonic() + 12.0
    while time.monotonic() < deadline:
        result = run(
            "systemctl",
            "--user",
            "show",
            SERVICE,
            "--property=MainPID",
            "--value",
            check=False,
        )
        try:
            pid = int(result.stdout.strip())
        except ValueError:
            pid = 0
        if pid > 0 and Path(f"/proc/{pid}").exists():
            return pid
        time.sleep(0.15)
    raise RuntimeError(f"{SERVICE} did not expose a live MainPID within 12 seconds")


def send_command(binary: Path, command: str) -> None:
    result = run(str(binary), "--command", command, check=False)
    if result.returncode != 0:
        detail = result.stderr.strip() or result.stdout.strip() or "unknown error"
        raise RuntimeError(f"Realmheart command {command!r} failed: {detail}")


def read_proc_ticks(pid: int) -> int:
    raw = Path(f"/proc/{pid}/stat").read_text(encoding="utf-8")
    close = raw.rfind(")")
    if close < 0:
        raise RuntimeError("Unable to parse /proc process stat")
    fields = raw[close + 2 :].split()
    return int(fields[11]) + int(fields[12])


def read_kib_map(path: Path) -> dict[str, int]:
    values: dict[str, int] = {}
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except (FileNotFoundError, PermissionError):
        return values
    for line in lines:
        if ":" not in line:
            continue
        name, value = line.split(":", 1)
        pieces = value.strip().split()
        if pieces and pieces[0].isdigit():
            values[name] = int(pieces[0])
    return values


def memory_snapshot(pid: int) -> tuple[int, int, int, int, int, int, int]:
    status = read_kib_map(Path(f"/proc/{pid}/status"))
    rollup = read_kib_map(Path(f"/proc/{pid}/smaps_rollup"))

    rss = rollup.get("Rss", status.get("VmRSS", 0))
    pss = rollup.get("Pss", rss)
    private = rollup.get("Private_Clean", 0) + rollup.get("Private_Dirty", 0)
    anonymous = rollup.get("Anonymous", status.get("RssAnon", 0))
    swap = rollup.get("Swap", status.get("VmSwap", 0))
    threads = status.get("Threads", 0)
    try:
        fds = sum(1 for _ in Path(f"/proc/{pid}/fd").iterdir())
    except (FileNotFoundError, PermissionError):
        fds = 0
    return rss, pss, private, anonymous, swap, threads, fds


def sample_phase(
    pid: int,
    phase: str,
    duration_s: float,
    interval_s: float,
    samples: list[Sample],
    action: Callable[[float], None] | None = None,
) -> None:
    clock_ticks = os.sysconf(os.sysconf_names["SC_CLK_TCK"])
    started = time.monotonic()
    previous_time = started
    previous_ticks = read_proc_ticks(pid)
    deadline = started + duration_s

    while True:
        now = time.monotonic()
        if now >= deadline:
            break
        if action is not None:
            action(now - started)

        sleep_for = min(interval_s, max(deadline - now, 0.0))
        time.sleep(sleep_for)
        current_time = time.monotonic()
        current_ticks = read_proc_ticks(pid)
        elapsed = max(current_time - previous_time, 1e-6)
        cpu = ((current_ticks - previous_ticks) / clock_ticks) / elapsed * 100.0
        rss, pss, private, anonymous, swap, threads, fds = memory_snapshot(pid)
        samples.append(
            Sample(
                phase=phase,
                elapsed_s=current_time - started,
                cpu_one_core_pct=cpu,
                rss_kib=rss,
                pss_kib=pss,
                private_kib=private,
                anonymous_kib=anonymous,
                swap_kib=swap,
                threads=threads,
                fds=fds,
            )
        )
        previous_time = current_time
        previous_ticks = current_ticks


def median(samples: Iterable[Sample], field: str) -> float:
    values = [float(getattr(sample, field)) for sample in samples]
    return statistics.median(values) if values else 0.0


def maximum(samples: Iterable[Sample], field: str) -> float:
    values = [float(getattr(sample, field)) for sample in samples]
    return max(values, default=0.0)


def format_mib(kib: float) -> str:
    return f"{kib / 1024.0:.2f} MiB"


def write_results(output_dir: Path, pid: int, samples: list[Sample]) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    csv_path = output_dir / f"realmheart-tessia-profile-{stamp}.csv"
    summary_path = output_dir / f"realmheart-tessia-profile-{stamp}.txt"

    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(Sample.__dataclass_fields__.keys())
        for sample in samples:
            writer.writerow(
                [
                    sample.phase,
                    f"{sample.elapsed_s:.4f}",
                    f"{sample.cpu_one_core_pct:.3f}",
                    sample.rss_kib,
                    sample.pss_kib,
                    sample.private_kib,
                    sample.anonymous_kib,
                    sample.swap_kib,
                    sample.threads,
                    sample.fds,
                ]
            )

    grouped: dict[str, list[Sample]] = {}
    for sample in samples:
        grouped.setdefault(sample.phase, []).append(sample)

    cold_baseline = grouped.get("disabled_closed_cold", [])
    disabled_idle = grouped.get("disabled_open_idle", [])
    disabled_stress = grouped.get("disabled_open_close_stress", [])
    baseline = grouped.get("disabled_closed_warm", [])
    loaded = grouped.get("enabled_closed", [])
    enabled_idle = grouped.get("enabled_open_idle", [])
    enabled_stress = grouped.get("enabled_open_close_stress", [])
    released = grouped.get("disabled_released", [])
    loaded_warm = grouped.get("enabled_closed_warm", [])
    released_warm = grouped.get("disabled_released_warm", [])

    cold_baseline_pss = median(cold_baseline, "pss_kib")
    baseline_pss = median(baseline, "pss_kib")
    disabled_idle_pss = median(disabled_idle, "pss_kib")
    loaded_pss = median(loaded, "pss_kib")
    enabled_idle_pss = median(enabled_idle, "pss_kib")
    released_pss = median(released, "pss_kib")
    loaded_warm_pss = median(loaded_warm, "pss_kib")
    released_warm_pss = median(released_warm, "pss_kib")

    sidebar_idle_cpu = median(disabled_idle, "cpu_one_core_pct")
    enabled_idle_cpu = median(enabled_idle, "cpu_one_core_pct")
    tessia_idle_cpu = enabled_idle_cpu - sidebar_idle_cpu
    disabled_stress_median = median(disabled_stress, "cpu_one_core_pct")
    enabled_stress_median = median(enabled_stress, "cpu_one_core_pct")
    disabled_stress_peak = maximum(disabled_stress, "cpu_one_core_pct")
    enabled_stress_peak = maximum(enabled_stress, "cpu_one_core_pct")

    lines = [
        "Realmheart Tessia performance probe",
        f"PID: {pid}",
        "CPU values are percentages of one logical CPU core.",
        "",
        "Per-phase medians / peaks:",
    ]
    for phase in grouped:
        phase_samples = grouped[phase]
        lines.append(
            f"  {phase:20s} "
            f"PSS {format_mib(median(phase_samples, 'pss_kib')):>10s}  "
            f"RSS {format_mib(median(phase_samples, 'rss_kib')):>10s}  "
            f"CPU median {median(phase_samples, 'cpu_one_core_pct'):6.2f}%  "
            f"peak {maximum(phase_samples, 'cpu_one_core_pct'):6.2f}%"
        )

    lines.extend(
        [
            "",
            "Isolated Tessia cost:",
            f"  renderer warm-up while disabled: {format_mib(baseline_pss - cold_baseline_pss)} PSS",
            f"  decoded/loaded while closed:     {format_mib(loaded_pss - baseline_pss)} PSS",
            f"  open PSS over disabled-open:     {format_mib(enabled_idle_pss - disabled_idle_pss)} PSS",
            f"  sidebar-only idle CPU median:    {sidebar_idle_cpu:.2f}%",
            f"  sidebar + Tessia idle median:    {enabled_idle_cpu:.2f}%",
            f"  Tessia incremental idle CPU:     {tessia_idle_cpu:+.2f}%",
            f"  disabled stress CPU median:      {disabled_stress_median:.2f}%",
            f"  enabled stress CPU median:       {enabled_stress_median:.2f}%",
            f"  Tessia stress median difference: {enabled_stress_median - disabled_stress_median:+.2f}%",
            f"  disabled animation stress peak:  {disabled_stress_peak:.2f}%",
            f"  enabled animation stress peak:   {enabled_stress_peak:.2f}%",
            f"  Tessia stress peak difference:   {enabled_stress_peak - disabled_stress_peak:+.2f}%",
            "",
            "Release check:",
            f"  first-cycle retained delta:      {format_mib(released_pss - baseline_pss)} PSS",
            f"  warm loaded delta:               {format_mib(loaded_warm_pss - released_pss)} PSS",
            f"  warm release residue:            {format_mib(released_warm_pss - released_pss)} PSS",
            f"  first-cycle FDs:                 {median(released, 'fds'):.0f} "
            f"(warmed disabled baseline {median(baseline, 'fds'):.0f})",
            f"  warm-cycle FDs:                  {median(released_warm, 'fds'):.0f} "
            f"(warm baseline {median(released, 'fds'):.0f})",
            f"  warm-cycle threads:              {median(released_warm, 'threads'):.0f} "
            f"(warm baseline {median(released, 'threads'):.0f})",
            "",
            f"Raw samples: {csv_path}",
        ]
    )
    summary_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return csv_path, summary_path


def main() -> int:
    args = parse_args()
    binary = args.binary.resolve()
    if not binary.is_file() or not os.access(binary, os.X_OK):
        print(f"error: executable not found: {binary}", file=sys.stderr)
        return 2
    if args.interval < 0.10 or args.interval > 2.0:
        print("error: --interval must be between 0.10 and 2.0 seconds", file=sys.stderr)
        return 2

    pref_path = preference_path()
    original_pref = pref_path.read_bytes() if pref_path.exists() else None
    original_enabled = preference_enabled(original_pref)
    samples: list[Sample] = []
    character_enabled = False
    sidebar_open = False

    baseline_duration = 3.0 if args.quick else 6.0
    loaded_duration = 3.0 if args.quick else 6.0
    idle_duration = 6.0 if args.quick else 12.0
    release_duration = 3.0 if args.quick else 6.0
    stress_cycles = 3 if args.quick else 6

    try:
        print("[1/11] Establishing cold character-disabled baseline...")
        write_preference(pref_path, False)
        pid = restart_service()
        time.sleep(1.5)
        sample_phase(
            pid,
            "disabled_closed_cold",
            baseline_duration,
            args.interval,
            samples,
        )

        print("[2/11] Measuring sidebar-open idle with Tessia disabled...")
        send_command(binary, "sidebar-right-toggle")
        sidebar_open = True
        time.sleep(0.8)
        sample_phase(
            pid,
            "disabled_open_idle",
            idle_duration,
            args.interval,
            samples,
        )

        def run_stress_phase(phase: str) -> None:
            nonlocal sidebar_open
            if sidebar_open:
                send_command(binary, "sidebar-right-toggle")
                sidebar_open = False
                time.sleep(0.45)

            event_times: list[tuple[float, str]] = []
            cursor = 0.25
            for _ in range(stress_cycles):
                event_times.append((cursor, "open"))
                cursor += 0.70
                event_times.append((cursor, "close"))
                cursor += 0.60
            next_event = 0

            def stress_action(elapsed: float) -> None:
                nonlocal next_event, sidebar_open
                while (
                    next_event < len(event_times)
                    and elapsed >= event_times[next_event][0]
                ):
                    send_command(binary, "sidebar-right-toggle")
                    sidebar_open = event_times[next_event][1] == "open"
                    next_event += 1

            sample_phase(
                pid,
                phase,
                cursor + 0.35,
                args.interval,
                samples,
                stress_action,
            )
            if sidebar_open:
                send_command(binary, "sidebar-right-toggle")
                sidebar_open = False
            time.sleep(0.5)

        print("[3/11] Measuring sidebar animation with Tessia disabled...")
        run_stress_phase("disabled_open_close_stress")

        print("[4/11] Capturing warmed disabled/closed baseline...")
        sample_phase(
            pid,
            "disabled_closed_warm",
            baseline_duration,
            args.interval,
            samples,
        )

        print("[5/11] Loading Tessia while sidebar remains closed...")
        send_command(binary, "character-toggle")
        character_enabled = True
        time.sleep(1.0)
        sample_phase(pid, "enabled_closed", loaded_duration, args.interval, samples)

        print("[6/11] Measuring sidebar-open idle with Tessia enabled...")
        send_command(binary, "sidebar-right-toggle")
        sidebar_open = True
        time.sleep(0.8)
        sample_phase(
            pid,
            "enabled_open_idle",
            idle_duration,
            args.interval,
            samples,
        )

        print("[7/11] Measuring sidebar animation with Tessia enabled...")
        run_stress_phase("enabled_open_close_stress")

        print("[8/11] Rechecking loaded-but-closed steady state...")
        sample_phase(pid, "enabled_closed_after", loaded_duration, args.interval, samples)

        print("[9/11] Destroying character resources and checking release...")
        send_command(binary, "character-toggle")
        character_enabled = False
        time.sleep(1.0)
        sample_phase(pid, "disabled_released", release_duration, args.interval, samples)

        print("[10/11] Repeating a warmed load/render/close cycle...")
        send_command(binary, "character-toggle")
        character_enabled = True
        time.sleep(0.7)
        send_command(binary, "sidebar-right-toggle")
        sidebar_open = True
        time.sleep(1.4)
        send_command(binary, "sidebar-right-toggle")
        sidebar_open = False
        time.sleep(0.5)
        sample_phase(pid, "enabled_closed_warm", loaded_duration, args.interval, samples)

        print("[11/11] Destroying warmed character resources and checking residue...")
        send_command(binary, "character-toggle")
        character_enabled = False
        time.sleep(1.0)
        sample_phase(
            pid,
            "disabled_released_warm",
            release_duration,
            args.interval,
            samples,
        )

        csv_path, summary_path = write_results(args.output_dir, pid, samples)
        print()
        print(summary_path.read_text(encoding="utf-8"), end="")
        print(f"Summary: {summary_path}")
        print(f"CSV:     {csv_path}")
        return 0
    except (OSError, RuntimeError, subprocess.SubprocessError) as error:
        print(f"probe failed: {error}", file=sys.stderr)
        return 1
    finally:
        try:
            if sidebar_open:
                send_command(binary, "sidebar-right-toggle")
                time.sleep(0.4)
            if character_enabled != original_enabled:
                send_command(binary, "character-toggle")
            restore_preference(pref_path, original_pref)
        except Exception as cleanup_error:  # best-effort state restoration
            print(f"warning: cleanup could not fully restore state: {cleanup_error}", file=sys.stderr)


if __name__ == "__main__":
    raise SystemExit(main())
