#!/usr/bin/env python3
"""Shared process identity and Linux memory accounting for wallpaper stress tests."""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_KIB_RE = re.compile(r"^\s*(\d+)\s+kB\s*$")
_SMAP_HEADER_RE = re.compile(
    r"^[0-9a-f]+-[0-9a-f]+\s+\S+\s+\S+\s+\S+\s+\d+\s*(.*)$"
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def get_binary_info(path: os.PathLike[str] | str) -> dict[str, Any] | None:
    candidate = Path(path).expanduser().resolve()
    if not candidate.is_file():
        return None
    stat = candidate.stat()
    build_id = ""
    try:
        output = subprocess.run(
            ["readelf", "-n", str(candidate)],
            check=False,
            capture_output=True,
            text=True,
        ).stdout
        match = re.search(r"Build ID:\s*(\S+)", output)
        if match:
            build_id = match.group(1)
    except OSError:
        pass
    return {
        "path": str(candidate),
        "sha256": _sha256(candidate),
        "inode": stat.st_ino,
        "size_bytes": stat.st_size,
        "build_id": build_id,
    }


def find_shell_pid(binary_path: os.PathLike[str] | str) -> int:
    expected = get_binary_info(binary_path)
    if expected is None:
        raise RuntimeError(f"binary does not exist: {binary_path}")

    matches: list[int] = []
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            cmdline = (entry / "cmdline").read_bytes().split(b"\0")
            if b"--shell" not in cmdline:
                continue
            executable = (entry / "exe").resolve()
            actual = get_binary_info(executable)
            if actual and actual["sha256"] == expected["sha256"]:
                matches.append(int(entry.name))
        except (FileNotFoundError, PermissionError, ProcessLookupError, OSError):
            continue

    if len(matches) != 1:
        raise RuntimeError(
            f"expected exactly one --shell process for {expected['path']}, found {matches}"
        )
    return matches[0]


def _read_kib_file(path: Path) -> dict[str, int]:
    values: dict[str, int] = {}
    for line in path.read_text().splitlines():
        if ":" not in line:
            continue
        key, raw = line.split(":", 1)
        match = _KIB_RE.match(raw)
        if match:
            values[key] = int(match.group(1))
    return values


def _mapping_totals(pid: int) -> dict[str, int]:
    totals = {
        "heap_rss_kib": 0,
        "heap_private_kib": 0,
        "anonymous_rss_kib": 0,
        "anonymous_private_kib": 0,
        "glycin_frame_count": 0,
        "glycin_frame_rss_kib": 0,
        "glycin_frame_private_kib": 0,
        "graphics_rss_kib": 0,
        "graphics_private_kib": 0,
    }
    smaps = Path(f"/proc/{pid}/smaps").read_text().splitlines()
    current_name = ""
    current: dict[str, int] = {}

    def flush() -> None:
        if not current:
            return
        rss = current.get("Rss", 0)
        private = current.get("Private_Clean", 0) + current.get("Private_Dirty", 0)
        name = current_name
        if name == "[heap]":
            totals["heap_rss_kib"] += rss
            totals["heap_private_kib"] += private
        if not name or name.startswith("[anon") or name == "[heap]":
            totals["anonymous_rss_kib"] += rss
            totals["anonymous_private_kib"] += private
        if "glycin-frame" in name:
            totals["glycin_frame_count"] += 1
            totals["glycin_frame_rss_kib"] += rss
            totals["glycin_frame_private_kib"] += private
        lowered = name.lower()
        if any(token in lowered for token in ("i915", "iris", "libdrm", "vulkan", "/dri/")):
            totals["graphics_rss_kib"] += rss
            totals["graphics_private_kib"] += private

    for line in smaps:
        header = _SMAP_HEADER_RE.match(line)
        if header:
            flush()
            current_name = header.group(1).strip()
            current = {}
            continue
        if ":" in line:
            key, raw = line.split(":", 1)
            match = _KIB_RE.match(raw)
            if match:
                current[key] = int(match.group(1))
    flush()
    return totals


def _dma_bufs(pid: int) -> tuple[list[dict[str, Any]], dict[str, int]]:
    buffers: list[dict[str, Any]] = []
    drm = {"drm_total_system_kib": 0, "drm_resident_system_kib": 0}
    fd_root = Path(f"/proc/{pid}/fd")
    for fd in fd_root.iterdir():
        try:
            target = os.readlink(fd)
            info = (Path(f"/proc/{pid}/fdinfo") / fd.name).read_text()
        except OSError:
            continue
        if "drm-total-system0:" in info:
            for key, output_key in (
                ("drm-total-system0", "drm_total_system_kib"),
                ("drm-resident-system0", "drm_resident_system_kib"),
            ):
                match = re.search(rf"^{re.escape(key)}:\s*(\d+)\s+KiB$", info, re.MULTILINE)
                if match:
                    drm[output_key] += int(match.group(1))
        if not target.startswith("/dmabuf:"):
            continue
        fields: dict[str, str] = {}
        for line in info.splitlines():
            if ":" in line:
                key, value = line.split(":", 1)
                fields[key.strip()] = value.strip()
        buffers.append(
            {
                "fd": int(fd.name),
                "inode": int(fields.get("ino", "0")),
                "size_bytes": int(fields.get("size", "0")),
                "exporter": fields.get("exp_name", ""),
            }
        )
    buffers.sort(key=lambda item: (item["inode"], item["fd"]))
    return buffers, drm


def get_process_metrics(pid: int) -> dict[str, Any]:
    root = Path(f"/proc/{pid}")
    status = _read_kib_file(root / "status")
    rollup = _read_kib_file(root / "smaps_rollup")
    dma_bufs, drm = _dma_bufs(pid)
    metrics: dict[str, Any] = {
        "rss_kib": status.get("VmRSS", rollup.get("Rss", 0)),
        "pss_kib": rollup.get("Pss", 0),
        "private_clean_kib": rollup.get("Private_Clean", 0),
        "private_dirty_kib": rollup.get("Private_Dirty", 0),
        "private_kib": rollup.get("Private_Clean", 0) + rollup.get("Private_Dirty", 0),
        "anonymous_kib": rollup.get("Anonymous", 0),
        "swap_kib": rollup.get("Swap", 0),
        "fd_count": len(list((root / "fd").iterdir())),
        "thread_count": len(list((root / "task").iterdir())),
        "dma_buf_count": len(dma_bufs),
        "dma_buf_total_bytes": sum(item["size_bytes"] for item in dma_bufs),
        "dma_buf_sizes": [item["size_bytes"] for item in dma_bufs],
        "dma_buf_inodes": [item["inode"] for item in dma_bufs],
    }
    metrics.update(drm)
    metrics.update(_mapping_totals(pid))
    return metrics


def collect_sample(pid: int, iteration: int, image: str, phase: str = "measure") -> dict[str, Any]:
    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "pid": pid,
        "iteration": iteration,
        "phase": phase,
        "image": image,
        **get_process_metrics(pid),
    }


def csv_value(value: Any) -> Any:
    if isinstance(value, (list, dict)):
        return json.dumps(value, separators=(",", ":"))
    return value


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--binary", default=str(Path.home() / ".local/bin/realmheart"))
    args = parser.parse_args()
    shell_pid = find_shell_pid(args.binary)
    result = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "pid": shell_pid,
        "binary": get_binary_info(args.binary),
        "metrics": get_process_metrics(shell_pid),
    }
    print(json.dumps(result, indent=2))
