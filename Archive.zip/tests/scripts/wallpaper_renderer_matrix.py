#!/usr/bin/env python3
"""Compare wallpaper retention and DMA-BUF behavior across GTK renderers."""

from __future__ import annotations

import argparse
import json
import subprocess
import time
from pathlib import Path

from wallpaper_memory_common import find_shell_pid, get_process_metrics


def run(*arguments: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(arguments, check=check, capture_output=True, text=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--binary", type=Path, default=Path.home() / ".local/bin/realmheart")
    parser.add_argument("--iterations", type=int, default=20)
    parser.add_argument("--settle", type=float, default=0.35)
    parser.add_argument("--output-dir", type=Path, default=Path("tests/results/renderer_matrix"))
    parser.add_argument("--renderers", nargs="+", default=["vulkan", "ngl", "gl", "cairo"])
    args = parser.parse_args()

    binary = args.binary.expanduser().resolve()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    summary: dict[str, object] = {}

    try:
        for renderer in args.renderers:
            print(f"=== renderer={renderer} ===", flush=True)
            run("systemctl", "--user", "set-environment", f"GSK_RENDERER={renderer}")
            run("systemctl", "--user", "restart", "realmheart.service")
            time.sleep(2.0)
            active = run("systemctl", "--user", "is-active", "realmheart.service", check=False)
            if active.returncode != 0:
                summary[renderer] = {"status": "startup-failed", "stderr": active.stderr}
                continue

            renderer_dir = args.output_dir / renderer
            command = [
                "python3", "tests/scripts/wallpaper_memory_stress.py",
                "--binary", str(binary),
                "--iterations", str(args.iterations),
                "--warmup", "5",
                "--settle", str(args.settle),
                "--allow-growth",
                "--output-dir", str(renderer_dir),
            ]
            completed = run(*command, check=False)
            print(completed.stdout, end="")
            reports = sorted(renderer_dir.glob("wallpaper_direct_*.json"), key=lambda path: path.stat().st_mtime)
            if completed.returncode not in (0, 1) or not reports:
                summary[renderer] = {
                    "status": "stress-failed",
                    "returncode": completed.returncode,
                    "stdout": completed.stdout,
                    "stderr": completed.stderr,
                }
                continue

            pid = find_shell_pid(binary)
            metrics = get_process_metrics(pid)
            report = json.loads(reports[-1].read_text(encoding="utf-8"))
            summary[renderer] = {
                "status": "ok",
                "pid": pid,
                "report": str(reports[-1]),
                "phases": report["phases"],
                "final_metrics": metrics,
            }
    finally:
        run("systemctl", "--user", "unset-environment", "GSK_RENDERER", check=False)
        run("systemctl", "--user", "restart", "realmheart.service", check=False)
        time.sleep(2.0)

    output = args.output_dir / "summary.json"
    output.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(f"summary={output}")
    if not any(value.get("status") == "ok" for value in summary.values() if isinstance(value, dict)):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
