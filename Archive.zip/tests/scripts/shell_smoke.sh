#!/usr/bin/env bash
set -euo pipefail

build_dir="${1:-build-hybrid}"
realmheart="${build_dir}/realmheart"

if [[ ! -x "${realmheart}" ]]; then
    printf 'Realmheart executable not found: %s\n' "${realmheart}" >&2
    exit 2
fi

started_shell=0
shell_pid=''
log_file="$(mktemp --tmpdir realmheart-shell-smoke.XXXXXX.log)"
cleanup() {
    if [[ "${started_shell}" == 1 && -n "${shell_pid}" ]] && kill -0 "${shell_pid}" 2>/dev/null; then
        "${realmheart}" --command quit >/dev/null 2>&1 || true
        wait "${shell_pid}" 2>/dev/null || true
    fi
    rm -f "${log_file}"
}
trap cleanup EXIT

command_reaches_shell() {
    timeout 3s "${realmheart}" --command "$@" >/dev/null 2>&1
}

if ! command_reaches_shell osd-volume; then
    "${realmheart}" --shell --wallpaper-backend gtk >"${log_file}" 2>&1 &
    shell_pid=$!
    started_shell=1

    ready=0
    for _ in $(seq 1 60); do
        if ! kill -0 "${shell_pid}" 2>/dev/null; then
            printf 'Realmheart exited during startup:\n' >&2
            cat "${log_file}" >&2
            exit 1
        fi
        if command_reaches_shell osd-volume; then
            ready=1
            break
        fi
        sleep 0.1
    done
    if [[ "${ready}" != 1 ]]; then
        printf 'Realmheart did not expose shell actions in time:\n' >&2
        cat "${log_file}" >&2
        exit 1
    fi
fi

# Toggle pairs restore the user's original visible state.
command_reaches_shell osd-brightness
command_reaches_shell sidebar-right-toggle
command_reaches_shell sidebar-right-toggle
command_reaches_shell bar-toggle
command_reaches_shell bar-toggle
command_reaches_shell toggle-notes
command_reaches_shell toggle-notes
command_reaches_shell generate-theme

if [[ "${started_shell}" == 1 ]] && ! kill -0 "${shell_pid}" 2>/dev/null; then
    printf 'Realmheart crashed during smoke actions:\n' >&2
    cat "${log_file}" >&2
    exit 1
fi

printf 'Realmheart shell smoke probe passed\n'
