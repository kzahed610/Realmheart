#!/usr/bin/env python3
"""Exercise the real GtkFileDialog selection path and measure retained memory."""

from __future__ import annotations

import argparse
import json
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from wallpaper_memory_common import collect_sample, find_shell_pid, get_binary_info
from wallpaper_memory_stress import summarize, write_csv


def run_ydotool(*arguments: str) -> None:
    subprocess.run(["ydotool", *arguments], check=True, stdout=subprocess.DEVNULL)


def picker_dialog_addresses() -> list[str]:
    clients = json.loads(subprocess.check_output(["hyprctl", "clients", "-j"], text=True))
    return [item["address"] for item in clients if item.get("title") == "Choose Wallpaper"]


def focus_new_picker_dialog(timeout: float = 4.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        addresses = picker_dialog_addresses()
        if len(addresses) == 1:
            expression = f'hl.dsp.focus({{ window = "address:{addresses[0]}" }})'
            subprocess.run(["hyprctl", "dispatch", expression], check=True, stdout=subprocess.DEVNULL)
            return
        if len(addresses) > 1:
            raise RuntimeError(f"picker automation found stacked dialogs: {addresses}")
        time.sleep(0.05)
    raise RuntimeError("picker dialog did not appear")


def wait_for_persisted_path(
    state_file: Path,
    expected: Path,
    previous_mtime_ns: int,
    timeout: float = 4.0,
) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            if (
                state_file.stat().st_mtime_ns != previous_mtime_ns
                and Path(state_file.read_text(encoding="utf-8").strip()) == expected
            ):
                return
        except OSError:
            pass
        time.sleep(0.05)
    raise RuntimeError(f"picker did not persist expected path: {expected}")


def select_path_through_picker(binary: Path, fixture: Path, state_file: Path, map_delay: float) -> None:
    if picker_dialog_addresses():
        raise RuntimeError("picker automation requires no pre-existing chooser dialogs")
    previous_mtime_ns = state_file.stat().st_mtime_ns if state_file.exists() else 0
    subprocess.run(
        [str(binary), "--command", "set-wallpaper"],
        check=True,
        stdout=subprocess.DEVNULL,
    )
    focus_new_picker_dialog()
    time.sleep(map_delay)
    # Ctrl+L focuses the location field in GTK's file chooser fallback.
    run_ydotool("key", "29:1", "38:1", "38:0", "29:0")
    time.sleep(0.05)
    run_ydotool("type", "--key-delay", "0", str(fixture))
    time.sleep(0.05)
    run_ydotool("key", "28:1", "28:0")
    time.sleep(0.1)
    # GTK's location entry resolves the file first; activate the now-enabled Open button.
    run_ydotool("key", "56:1", "24:1", "24:0", "56:0")
    wait_for_persisted_path(state_file, fixture, previous_mtime_ns)
    if picker_dialog_addresses():
        raise RuntimeError("picker dialog remained open after selection")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--binary", type=Path, default=Path.home() / ".local/bin/realmheart")
    parser.add_argument("--fixture-a", type=Path, default=Path("tests/fixtures/wallpapers/small.png"))
    parser.add_argument("--fixture-b", type=Path, default=Path("tests/fixtures/wallpapers/large.png"))
    parser.add_argument("--iterations", type=int, default=50)
    parser.add_argument("--warmup", type=int, default=3)
    parser.add_argument("--map-delay", type=float, default=0.6)
    parser.add_argument("--settle", type=float, default=0.5)
    parser.add_argument("--max-growth-kib", type=float, default=1024.0)
    parser.add_argument("--allow-growth", action="store_true")
    parser.add_argument("--output-dir", type=Path, default=Path("tests/results"))
    args = parser.parse_args()

    if args.iterations < 6 or args.warmup < 0:
        parser.error("iterations must be >= 6 and warmup must be non-negative")

    binary = args.binary.expanduser().resolve()
    fixtures = [args.fixture_a.resolve(), args.fixture_b.resolve()]
    state_file = Path.home() / ".local/state/realmheart/wallpaper/path.txt"
    pid = find_shell_pid(binary)
    binary_info = get_binary_info(binary)
    if binary_info is None:
        raise RuntimeError(f"binary does not exist: {binary}")
    for fixture in fixtures:
        if not fixture.is_file():
            raise RuntimeError(f"fixture does not exist: {fixture}")

    started_at = datetime.now(timezone.utc).isoformat()
    print(f"binary={binary} pid={pid} sha256={binary_info['sha256']}")
    for index in range(args.warmup):
        fixture = fixtures[index % len(fixtures)]
        select_path_through_picker(binary, fixture, state_file, args.map_delay)
        time.sleep(args.settle)

    samples: list[dict[str, Any]] = []
    for index in range(args.iterations):
        fixture = fixtures[index % len(fixtures)]
        select_path_through_picker(binary, fixture, state_file, args.map_delay)
        time.sleep(args.settle)
        sample = collect_sample(pid, index, f"picker-{fixture.stem}")
        samples.append(sample)
        if index % 10 == 0 or index == args.iterations - 1:
            print(
                f"{index + 1:02d}/{args.iterations}: PSS={sample['pss_kib']} KiB "
                f"private-dirty={sample['private_dirty_kib']} KiB fd={sample['fd_count']}"
            )

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path = args.output_dir / f"wallpaper_picker_{stamp}.csv"
    report_path = args.output_dir / f"wallpaper_picker_{stamp}.json"
    write_csv(csv_path, samples)
    report = {
        "binary": binary_info,
        "pid": pid,
        "iterations": args.iterations,
        "warmup": args.warmup,
        **summarize(samples),
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

    journal = subprocess.run(
        ["journalctl", "--user", "-u", "realmheart.service", "--since", started_at, "--no-pager"],
        check=False,
        capture_output=True,
        text=True,
    ).stdout
    ownership_critical = "g_list_store_append: assertion" in journal
    worst_growth = max(
        phase[metric]["median_delta"]
        for phase in report["phases"].values()
        for metric in ("pss_kib", "private_dirty_kib")
    )
    print(f"PSS/private-dirty growth={worst_growth:.1f} KiB")
    print(f"ownership-critical={'yes' if ownership_critical else 'no'}")
    print(f"csv={csv_path} report={report_path}")
    if (ownership_critical or worst_growth > args.max_growth_kib) and not args.allow_growth:
        print("RESULT=RED")
        return 1
    print("RESULT=GREEN" if not ownership_critical and worst_growth <= args.max_growth_kib else "RESULT=RED_ALLOWED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
