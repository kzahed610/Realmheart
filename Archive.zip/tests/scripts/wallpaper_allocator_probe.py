#!/usr/bin/env python3
"""Diagnostic allocator-retention probe; restores the normal service on exit."""

from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import tempfile
import time
from pathlib import Path

from wallpaper_memory_common import collect_sample, find_shell_pid, get_binary_info

PRELOAD_SOURCE = r'''
#define _GNU_SOURCE
#include <fcntl.h>
#include <malloc.h>
#include <pthread.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>

static void *trim_worker(void *unused) {
    (void)unused;
    sigset_t set;
    sigemptyset(&set);
    sigaddset(&set, SIGUSR2);
    int received = 0;
    if (sigwait(&set, &received) == 0) {
        int result = malloc_trim(0);
        const char *marker = getenv("REALMHEART_TRIM_MARKER");
        if (marker) {
            int fd = open(marker, O_WRONLY | O_CREAT | O_TRUNC, 0600);
            if (fd >= 0) {
                char value = result ? '1' : '0';
                (void)write(fd, &value, 1);
                close(fd);
            }
        }
    }
    return NULL;
}

__attribute__((constructor)) static void install_trim_worker(void) {
    sigset_t set;
    sigemptyset(&set);
    sigaddset(&set, SIGUSR2);
    pthread_sigmask(SIG_BLOCK, &set, NULL);
    pthread_t thread;
    if (pthread_create(&thread, NULL, trim_worker, NULL) == 0)
        pthread_detach(thread);
}
'''


def run(*args: str) -> None:
    subprocess.run(args, check=True, stdout=subprocess.DEVNULL)


def apply(binary: Path, fixture: Path) -> None:
    run(str(binary), "--command", "set-wallpaper-path", str(fixture))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--binary", type=Path, default=Path.home() / ".local/bin/realmheart")
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--settle", type=float, default=0.4)
    parser.add_argument("--output", type=Path, default=Path("tests/results/wallpaper_allocator_probe.json"))
    args = parser.parse_args()

    binary = args.binary.expanduser().resolve()
    binary_info = get_binary_info(binary)
    if binary_info is None:
        raise RuntimeError(f"binary does not exist: {binary}")
    small = Path("tests/fixtures/wallpapers/small.png").resolve()
    huge = Path("tests/fixtures/wallpapers/huge.png").resolve()

    result: dict[str, object] = {"binary": binary_info}
    with tempfile.TemporaryDirectory(prefix="hermes-allocator-probe-") as directory:
        root = Path(directory)
        source = root / "trim_probe.c"
        library = root / "trim_probe.so"
        marker = root / "trim.complete"
        source.write_text(PRELOAD_SOURCE, encoding="utf-8")
        run("cc", "-shared", "-fPIC", "-O2", "-pthread", str(source), "-o", str(library))

        try:
            run(
                "systemctl", "--user", "set-environment",
                f"LD_PRELOAD={library}",
                f"REALMHEART_TRIM_MARKER={marker}",
            )
            run("systemctl", "--user", "restart", "realmheart.service")
            time.sleep(2.0)
            pid = find_shell_pid(binary)
            result["instrumented_pid"] = pid

            for index in range(args.cycles):
                apply(binary, huge if index % 2 else small)
                time.sleep(args.settle)
            apply(binary, small)
            time.sleep(1.5)
            before = collect_sample(pid, 0, "small-before-trim", "probe")

            os.kill(pid, signal.SIGUSR2)
            deadline = time.monotonic() + 5.0
            while time.monotonic() < deadline and not marker.exists():
                time.sleep(0.05)
            if not marker.exists():
                raise RuntimeError("malloc_trim probe did not acknowledge SIGUSR2")
            time.sleep(1.0)
            after = collect_sample(pid, 1, "small-after-trim", "probe")
            result["malloc_trim_returned"] = marker.read_text(encoding="utf-8") == "1"
            result["before"] = before
            result["after"] = after
            result["delta_after_trim"] = {
                key: after[key] - before[key]
                for key in (
                    "rss_kib", "pss_kib", "private_dirty_kib", "private_kib",
                    "anonymous_kib", "heap_private_kib", "glycin_frame_count",
                    "dma_buf_count", "fd_count",
                )
            }
        finally:
            subprocess.run(
                ["systemctl", "--user", "unset-environment", "LD_PRELOAD", "REALMHEART_TRIM_MARKER"],
                check=False,
                stdout=subprocess.DEVNULL,
            )
            subprocess.run(
                ["systemctl", "--user", "restart", "realmheart.service"],
                check=False,
                stdout=subprocess.DEVNULL,
            )
            time.sleep(2.0)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    delta = result["delta_after_trim"]
    print(json.dumps(delta, indent=2))
    print(f"malloc_trim_returned={result['malloc_trim_returned']} output={args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
